#!/usr/bin/env python3
import os

with open('/tmp/String.txt') as f_str:
    s=f_str.read()
res=""
for fs in s:
    if fs.isdigit():
        res +=fs
print(res)
