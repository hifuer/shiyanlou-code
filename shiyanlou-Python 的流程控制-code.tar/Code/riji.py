for i in range(1,11):
	print('书恒走的第{}天，想他'.format(i))
