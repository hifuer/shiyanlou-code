#!/usr/bin/env python3
import math

maji=2 * 2 * math.pi

print("{:.10f}".format(maji))
