<html class="" lang="en"><head>
    <meta charset="UTF-8">
    <title>\u7b80\u5386\u751f\u6210\u5668</title>
    <link rel="stylesheet" href="static/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remodal/1.1.0/remodal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remodal/1.1.0/remodal-default-theme.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/remodal/1.1.0/remodal.min.js"></script>
    <script src="static/js/script.js"></script>
</head>

<body style="padding-right: 0px;">
    <div class="container" id="cv">
        <div class="side">
            <div class="me">
                <div class="portrait"></div>
                
                <h1 id="username" contenteditable="true">hifuer<br></h1>
                <h4 id="persona-tag" contenteditable="true">Python <br></h4>
            </div>
            <div class="profile info-unit">
                <h2 class="info-header"><i class="iconfont icon-person"></i> <span class="info-title" contenteditable="true">\u57fa\u672c\u4fe1\u606f</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="info-list">
                    <li>
                        <label class="left-label" contenteditable="true">\u59d3\u540d</label><span class="label-value" contenteditable="true">\u5b59\u798f\u5b58</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">\u5b66\u5386</label><span class="label-value" contenteditable="true">\u521d\u4e2d</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    
                    <li>
                        <label class="left-label" contenteditable="true">\u6bd5\u4e1a\u5e74\u4efd</label><span class="label-value" contenteditable="true">2009</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                </ul>
            </div>
            <div class="contact info-unit">
                <h2 class="info-header"><i class="iconfont icon-call"></i> <span class="info-title" contenteditable="true">\u8054\u7cfb\u65b9\u5f0f</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="info-list">
                    <li>
                        <label class="left-label" contenteditable="true">\u624b\u673a</label><span class="label-value" contenteditable="true">156xxxxxxx</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">\u90ae\u7bb1</label><span class="label-value" contenteditable="true">hifuer@qq.com</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">\u4e2a\u4eba\u4e3b\u9875</label><span class="label-value" contenteditable="true">http</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">Github</label><span class="label-value" contenteditable="true">github.com/hifuer</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                </ul>
            </div>
            <div class="skill info-unit">
                <h2 class="info-header"><i class="iconfont icon-star"></i> <span class="info-title" contenteditable="true">\u6280\u80fd\u70b9</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="progress-list">
                    <li>
                        <label class="left-label" contenteditable="true">Python</label>
                        <progress value="80" max="100"></progress>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">html/css</label>
                        <progress value="3.125" max="100"></progress>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <label class="left-label" contenteditable="true">Javascript</label><li>
                        
                        <progress value="1.5625" max="100"></progress>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <label class="left-label" contenteditable="true">\u673a\u5668\u5b66\u4e60</label>
                        <progress value="0.78125" max="100"></progress>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                </ul>
            </div>
            <div class="stack info-unit">
                <h2 class="info-header"><i class="iconfont icon-build"></i> <span class="info-title" contenteditable="true">\u6280\u672f\u6808</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="stack-list">
                    <li>
                        <label class="left-label" contenteditable="true">\u524d\u7aef</label><span class="label-value" contenteditable="true">jQuery</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    
                    <li>
                        <label class="left-label" contenteditable="true">\u540e\u7aef</label><span class="label-value" contenteditable="true">Django\u3001MySQL\u3001Redis</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    
                    <li>
                        <label class="left-label" contenteditable="true">\u5176\u5b83</label><span class="label-value" contenteditable="true">\u6211\u5168\u90fd\u662f\u778e\u5199\u7684\u3002</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    
                <li>
                        <label class="left-label" contenteditable="true">\u524d\u7aef</label><span class="label-value" contenteditable="true">jQuery</span><span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li></ul>
            </div>

            <div class="code info-unit">
                <h2 class="info-header"><i class="iconfont icon-weixin"></i> <span class="info-title" contenteditable="true">\u4e2a\u4eba\u5fae\u4fe1</span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <div class="weixin">
                    <img src="static/image/weixin.png" alt="">

                </div>
            </div>
            
        </div>
        <div class="main">
            <div class="education info-unit right-list">
                <h2 class="info-header"><i class="iconfont icon-education"></i> <span class="info-title" contenteditable="true">\u6559\u80b2\u7ecf\u5386</span><span class="item-add"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="experience-list">
                    <li>
                        <h3 contenteditable="true">\u5317\u4eac\u90ae\u7535\u5927\u5b66 - \u7f51\u7edc\u5de5\u7a0b\u4e13\u4e1a\uff08\u672c\u79d1\uff092012-2017</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                </ul>
            </div>
            <div class="work info-unit right-list">
                <h2 class="info-header"><i class="iconfont icon-work"></i> <span class="info-title" contenteditable="true">\u5de5\u4f5c\u7ecf\u5386</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="experience-list">
                    <li>
                        <h3 contenteditable="true">\u5317\u4eac\u521b\u5ba2\u7a7a\u95f4\uff0d\u5b9e\u4e60\u751f\uff08\u5b9e\u4e60\uff09</h3>
                        <p contenteditable="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <h3 contenteditable="true">\u5b9e\u9a8c\u697c\uff0d\u8bfe\u7a0b\u5185\u5bb9\uff08\u5b9e\u4e60\uff09</h3>
                        <p contenteditable="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                </ul>
            </div>
            <div class="project info-unit right-list">
                <h2 class="info-header"><i class="iconfont icon-project"></i> <span class="info-title" contenteditable="true">\u4e2a\u4eba\u9879\u76ee</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="experience-list">
                    <li>
                        <h3 contenteditable="true">\u57fa\u4e8e Qt 5 \u7684\u6587\u672c\u7f16\u8f91\u5668</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam\u3002Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            <br>
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <h3 contenteditable="true">\u57fa\u4e8e Flask \u7684\u4e3b\u673a\u76d1\u89c6\u7cfb\u7edf</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    <li>
                        <h3 contenteditable="true">\u57fa\u4e8e Live2D \u4e0e clmtrackr \u7684\u5c71\u5be8 Facerig</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li>
                    
                </ul>
            </div>
            <div class="trophy info-unit">
                <h2 class="info-header"><i class="iconfont icon-trophy"></i> <span class="info-title" contenteditable="true">\u5956\u9879\u4e0e\u8bc1\u4e66</span><span class="item-add" style="visibility: hidden;"><i class="iconfont icon-playlistadd"></i></span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <ul class="experience-list">
                    <li>
                        <h3 contenteditable="true">\u5c0f\u5b66\u751f\u4f5c\u6587\u4e8c\u7b49\u5956</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam\u3002
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li> 
                    <li>
                        <h3 contenteditable="true">\u66fe\u83b7\u7edf\u4e00\u51b0\u7ea2\u8336\u201c\u518d\u6765\u4e00\u74f6\u201d\u5956</h3>
                        <p contenteditable="true">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam\u3002
                        </p>
                    <span class="item-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></li> 
                                         
            </ul></div>
            <div class="aboutme info-unit right-paragraph">
                <h2 class="info-header"><i class="iconfont icon-flower"></i> <span class="info-title" contenteditable="true">\u81ea\u6211\u8bc4\u4ef7</span><span class="unit-remove" style="visibility: hidden;"><i class="iconfont icon-delete"></i></span></h2>
                <hr>
                <p contenteditable="true">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>
        </div>
    </div>



<div class="remodal-overlay remodal-is-closed" style="display: none;"></div><div class="remodal-wrapper remodal-is-closed" style="display: none;"><div class="remodal remodal-img remodal-is-initialized remodal-is-closed" data-remodal-id="portrait-modal" tabindex="-1">
                    <h3 contenteditable="true">\u8bf7\u8f93\u5165\u56fe\u7247URL\u5730\u5740\uff1a</h3>
                    <br>
                    <input type="text" id="avatar-url">
                    <button data-remodal-action="confirm" class="remodal-confirm">\u786e\u5b9a</button>
                </div></div><div class="remodal-wrapper remodal-is-closed" style="display: none;"><div class="remodal remodal-img remodal-is-initialized remodal-is-closed" data-remodal-id="weixin-modal" tabindex="-1">
                <h3 contenteditable="true">\u8bf7\u8f93\u5165\u56fe\u7247URL\u5730\u5740\uff1a</h3>
                <br>
                <input type="text" id="weixin-url">
                <button data-remodal-action="confirm" class="remodal-confirm">\u786e\u5b9a</button>
            </div></div></body></html>
