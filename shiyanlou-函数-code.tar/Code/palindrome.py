#!/usr/bin/env python3
s=input("Please enter a string: ")
z=s[::-1]
if s == z:
    print("The string is a palindrome")
else:
    print("The strign is not a palindrome")

