#!/usr/bin/env python3
def change():
    global a
    a=100
    print(a)
a=9
print("Befor the function all", a,)
print("insid change function", end=' ')
change()
print("After the function all", a,)
