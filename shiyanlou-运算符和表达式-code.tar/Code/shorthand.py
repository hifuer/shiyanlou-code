#!/usr/bin/env python3
N=100
a=2
while a<N:
    print(str(a))
    a *= a
