#!/usr/bin/env python3
a=9
b=12
c=3
x = a - b / 3 + c * 2 - 1
y = a - b / (3 + c) * (2 - 1)
z = a - (b / (3 + c) * 2) - 1
print("X=",x)
print("Y=",y)
print("z=",z)
